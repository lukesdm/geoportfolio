Data sources:
* Land cover: © Space Intelligence, licensed under Open Government License 3.0 - https://www.space-intelligence.com/scotland-landcover/
* Pubs, supermarkets and tracks/ways: © OpenStreetMap contributors, licensed under the Open Data Commons Open Database License (ODbL) - https://www.openstreetmap.org/copyright

Other content:
© Luke McQuade, licensed under CC-BY 4.0 - https://creativecommons.org/licenses/by/4.0/